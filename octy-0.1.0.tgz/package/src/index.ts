/**
 * Octy — DeFi Competitive Intelligence Agent
 * Project entry point: exports character + plugin for ElizaOS runtime.
 */

import type { Character, Plugin, Project } from "@elizaos/core";
import { defiDataPlugin } from "./plugins/defi-data/index";
import { nansenSmartMoneyPlugin } from "./plugins/nansen-smart-money/index";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

// Load character from JSON file
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const characterPath = path.join(
  __dirname,
  "..",
  "characters",
  "agent.character.json",
);
const character: Character = JSON.parse(
  fs.readFileSync(characterPath, "utf-8"),
);

// Merge providers and actions from sub-plugins
const octyPlugin: Plugin = {
  name: "octy",
  description:
    "DeFi competitive intelligence with real-time data from DeFiLlama, CoinGecko, Uniswap v3, and Nansen smart money.",
  providers: [
    ...(defiDataPlugin.providers ?? []),
    ...(nansenSmartMoneyPlugin.providers ?? []),
  ],
  actions: [
    ...(defiDataPlugin.actions ?? []),
    ...(nansenSmartMoneyPlugin.actions ?? []),
  ],
};

const project: Project = {
  agents: [
    {
      character,
      plugins: [octyPlugin],
    },
  ],
};

export default project;
