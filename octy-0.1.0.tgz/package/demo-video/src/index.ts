// Remotion root registration — must export the root component
export { RemotionRoot } from "./Root";
